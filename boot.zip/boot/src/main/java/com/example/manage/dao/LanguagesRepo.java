package com.example.manage.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.manage.entity.Languages;

public interface LanguagesRepo extends CrudRepository<Languages, Integer>{

}
