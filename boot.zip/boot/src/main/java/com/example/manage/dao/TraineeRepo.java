package com.example.manage.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.manage.entity.Trainee;

public interface TraineeRepo extends CrudRepository<Trainee, Integer>
{

}
