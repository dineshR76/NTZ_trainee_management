package com.example.manage.Model;

public class Categories 
{
	
}
